/*import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backgroundImageContainer: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.5,
  },
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  countText: {
    fontSize: 48,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  buttonContainer: {
    flexDirection: 'row',
  },
});
*/
